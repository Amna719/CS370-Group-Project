public class WebBrowser implements MyObserver{
    //Student side
    @Override
    public void update(int info) {
        System.out.println("**Student Reservation Confirmed/Terminated**\n" + "There are " + info +
                " study spaces now available in the library");
    }

    @Override
    public void errorMessage(String s) {
        System.out.println("Web Browser: " + s);
    }
}