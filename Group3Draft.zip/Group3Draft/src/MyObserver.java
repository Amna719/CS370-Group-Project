public interface MyObserver {
    void update(int info); //for making and ending reservations
    void errorMessage(String s); //for error messages for making and ending reservations
}