public class DesktopApplication implements MyObserver{
    //Library side
    @Override
    public void update(int info) {
        System.out.println( "**Library Desk Top Updated**\n" +
                "A student just reserved study space(s). There are " + info +
                " study spaces available in the library\n");

    }
    @Override
    public void errorMessage(String s) {
        System.out.println("Desktop: " + s + "\n");
    }
}