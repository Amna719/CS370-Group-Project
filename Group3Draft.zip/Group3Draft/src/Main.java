import java.util.ArrayList;
import java.util.List;

public class Main {
    // 1) we created observers
    // 2) create a library - keep track of available spots
    // 3) made the library MyObservable so that MYObservers are notified
    // when num of study spaces change
    public static void main(String[] args) {
        Library rosenthal = new Library(100);
        rosenthal.addObserver(new WebBrowser());
        rosenthal.addObserver(new DesktopApplication());
        rosenthal.reserveStudySpace(10); //makes 10 reservation observers print 90 available
        rosenthal.endStudySpaceReservation(5); //end 5 reservation observers print 95 available

        rosenthal.reserveStudySpace(1000); //error message observers deny reservation
        rosenthal.endStudySpaceReservation(1000); //error message observers deny ending

        rosenthal.reserveStudySpace(20); //makes 20 reservation observers print 75 available
        rosenthal.endStudySpaceReservation(15);//end 15 reservation observers print 90 available
    }
}