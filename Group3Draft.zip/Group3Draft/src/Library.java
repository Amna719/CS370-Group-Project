public class Library extends MyObservable{
    private int studySpacesCap = 0;
    private int studySpaceReserved = 0;

    public Library(int studySpacesCap){   //Garage()
        this.studySpacesCap = studySpacesCap;
    }

    public boolean reserveStudySpace(int spaces){   //takeSpots()
        if(studySpacesAvailable() < spaces){
            sendErrorMessage("**Reservation Denied**\n" + spaces +
                    " spaces are not available in this library");
            return false;
        }
        setStudySpaceReserved(getStudySpaceReserved() + spaces);
        return true;
    }

    public void endStudySpaceReservation(int spaces){ //releaseSpots()
        if(getStudySpaceReserved() < spaces){
            sendErrorMessage("**End Reservation Denied**\n" + spaces +
                    " spaces is greater than the number of reservations made");
        }
        else{
            setStudySpaceReserved(getStudySpaceReserved() - spaces);
        }
    }

    public int getStudySpaceReserved() {  //getter
        return studySpaceReserved;
    }


    public void setStudySpaceReserved(int studySpaceReserved) {  //setter
        this.studySpaceReserved = studySpaceReserved;
        notifyObservers(studySpacesAvailable());
    }

    public int studySpacesAvailable() {     // spotsAvailable()
        return(studySpacesCap - getStudySpaceReserved());
    }
}
