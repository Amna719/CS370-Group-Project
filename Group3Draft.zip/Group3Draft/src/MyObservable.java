import java.util.ArrayList;
import java.util.List;

public class MyObservable {
    List<MyObserver> observers = new ArrayList<>();
    void notifyObservers (int info) {
        for(MyObserver o : observers){
            o.update(info);
        }
    }
    void sendErrorMessage(String s){ //added for error messages to observers
        for(MyObserver o : observers){
            o.errorMessage(s);
        }
    }
    public void addObserver (MyObserver o) {
        observers.add(o);
    }
    public void removeObserver (MyObserver o) {
        observers.remove(o);
    }
}